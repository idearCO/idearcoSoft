from dependencies import *

# Obtener permisos de acceso (simulando para el ejemplo)
def get_user_access():
    # Simulación de permisos: Admin tiene acceso a todo
    return ["Administración", "RR.HH", "KPI"]

def open_script(script_name):
    script_path = os.path.join(SCRIPTS_PATH, script_name)
    try:
        subprocess.Popen([sys.executable, script_path], shell=True)
    except Exception as e:
        print(f"[ERROR] No se pudo ejecutar el script {script_name}: {e}")

# Crear la ventana principal
root = tk.Tk()
root.title("IdearcoSoft - Dashboard")
root.geometry("800x600")

# Frame principal con el logo
top_frame = tk.Frame(root)
top_frame.pack(side="top", fill="x")

# Logo de la empresa
try:
    logo_path = os.path.join(FAVICON_PATH, "logo.png")
    logo_image = Image.open(logo_path)
    logo_image = logo_image.resize((100, 100), Image.LANCZOS)
    logo = ImageTk.PhotoImage(logo_image)
    logo_label = Label(top_frame, image=logo)
    logo_label.pack(side="left", padx=10, pady=10)
except Exception as e:
    print(f"[ERROR] No se pudo cargar el logo: {e}")

# Crear el Notebook (pestañas)
notebook = ttk.Notebook(root)
notebook.pack(expand=True, fill="both")

# Función para crear botones con íconos
def create_button(frame, text, icon_name, script_name):
    try:
        icon_path = os.path.join(FAVICON_PATH, icon_name)
        icon_image = Image.open(icon_path)
        icon_image = icon_image.resize((50, 50), Image.LANCZOS)
        icon = ImageTk.PhotoImage(icon_image)
        button = tk.Button(frame, text=text, image=icon, compound="top", command=lambda: open_script(script_name))
        button.image = icon  # Mantener referencia
        button.pack(side="top", padx=20, pady=20)
    except Exception as e:
        print(f"[ERROR] No se pudo cargar el ícono '{icon_name}': {e}")

# Crear pestañas según los permisos del usuario
access = get_user_access()

# Pestaña Administración
if "Administración" in access:
    admin_frame = ttk.Frame(notebook)
    notebook.add(admin_frame, text="Administración")
    create_button(admin_frame, "Generar Factura", "factura.png", "generar_factura.py")
    create_button(admin_frame, "Gestión de Usuarios", "admin.png", "gestion_usuarios.py")
    create_button(admin_frame, "Control Financiero", "admin.png", "control_financiero.py")

# Pestaña RR.HH
if "RR.HH" in access:
    rrhh_frame = ttk.Frame(notebook)
    notebook.add(rrhh_frame, text="RR.HH")
    create_button(rrhh_frame, "Gestión de Empleados", "rrhh.png", "gestion_empleados.py")
    create_button(rrhh_frame, "Control de Asistencias", "rrhh.png", "control_asistencias.py")

# Pestaña KPI
if "KPI" in access:
    kpi_frame = ttk.Frame(notebook)
    notebook.add(kpi_frame, text="KPI")
    create_button(kpi_frame, "Reporte de Producción", "kpi.png", "reporte_produccion.py")
    create_button(kpi_frame, "Dashboard de Eficiencia", "kpi.png", "dashboard_eficiencia.py")

root.mainloop()
