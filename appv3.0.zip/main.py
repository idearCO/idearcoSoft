from dependencies import *

def get_config(key):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM config WHERE key=?", (key,))
        result = cursor.fetchone()
        conn.close()
        if result:
            return result[0]
        else:
            return None
    except Exception as e:
        print(f"[ERROR] No se pudo obtener el valor de configuración: {e}")
        return None

GITHUB_USER = "idearCO"
GITHUB_REPO = "idearcoSoft"
BRANCH = "releases"
TOKEN = get_config("token")  # Obtiene el token desde la base de datos
VERSION_FILE = f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/{BRANCH}/version.txt"
DOWNLOAD_URL = f"https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/{BRANCH}/app_v{{version}}.zip"

# Crear la ventana de Tkinter
root = tk.Tk()
root.title("IdearcoSoft - Actualización")
root.geometry("400x300")

# Mostrar el logo
try:
    logo_path = os.path.join(INSTALL_PATH, "favicon/logo.png")
    image = Image.open(logo_path)
    image = image.resize((150, 150), Image.LANCZOS)  # Cambiado de ANTIALIAS a LANCZOS
    logo = ImageTk.PhotoImage(image)
    logo_label = Label(root, image=logo)
    logo_label.pack(pady=10)
except Exception as e:
    print(f"[ERROR] No se pudo cargar el logo: {e}")


# Barra de progreso y mensajes
progress_label = Label(root, text="Iniciando...", font=("Arial", 12))
progress_label.pack(pady=5)

progress_bar = ttk.Progressbar(root, orient="horizontal", length=300, mode="determinate")
progress_bar.pack(pady=10)

# Botón para iniciar la aplicación principal
launch_button = Button(root, text="Continuar", command=lambda: launch_main_soft(), state="disabled")
launch_button.pack(pady=10)

def update_status(message, progress=None):
    progress_label.config(text=message)
    if progress is not None:
        progress_bar['value'] = progress
    root.update()

def install_requirements():
    try:
        requirements_path = os.path.join(INSTALL_PATH, "requirements.txt")
        if os.path.exists(requirements_path):
            update_status("Instalando dependencias...", 90)
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", requirements_path])
            update_status("Dependencias instaladas exitosamente.", 95)
        else:
            update_status("No se encontraron dependencias para instalar.", 95)
    except Exception as e:
        update_status(f"[ERROR] Error al instalar dependencias: {e}")

def get_installed_version():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM config WHERE key='version'")
        result = cursor.fetchone()
        conn.close()
        if result:
            return result[0]
        return "0.0"
    except Exception as e:
        update_status(f"[ERROR] No se pudo obtener la versión instalada: {e}")
        return "0.0"

def set_installed_version(version):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("REPLACE INTO config (key, value) VALUES (?, ?)", ("version", version))
        conn.commit()
        conn.close()
        update_status(f"[INFO] Versión instalada actualizada a: {version}")
    except Exception as e:
        update_status(f"[ERROR] No se pudo actualizar la versión: {e}")

def get_latest_version():
    try:
        response = requests.get(VERSION_FILE, headers={"Authorization": f"token {TOKEN}"})
        response.raise_for_status()
        return response.text.strip()
    except Exception as e:
        update_status(f"[ERROR] No se pudo obtener la última versión: {e}")
        return None

def download_and_install(version):
    url = DOWNLOAD_URL.format(version=version)
    zip_path = os.path.join(INSTALL_PATH, f"app_v{version}.zip")
    update_status("Descargando actualización...", 50)
    try:
        response = requests.get(url, stream=True, headers={"Authorization": f"token {TOKEN}"})
        response.raise_for_status()
        with open(zip_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        update_status("Extrayendo archivos...", 75)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(INSTALL_PATH)
        os.remove(zip_path)
        install_requirements()
        set_installed_version(version)
        update_status(f"Actualización completada a la versión {version}", 100)
        launch_button.config(state="normal")
    except Exception as e:
        update_status(f"[ERROR] Error al descargar o instalar la actualización: {e}")

def launch_main_soft():
    try:
        launcher_path = os.path.join(INSTALL_PATH, "main_dashboard.py")
        update_status("Ejecutando aplicación principal...", 100)
        subprocess.Popen([sys.executable, launcher_path], shell=True)
        root.destroy()
    except Exception as e:
        update_status(f"[ERROR] No se pudo lanzar la aplicación: {e}")

def update():
    update_status("Verificando actualizaciones...", 10)
    installed_version = get_installed_version()
    latest_version = get_latest_version()

    if latest_version and installed_version != latest_version:
        update_status(f"Nueva versión: {installed_version} -> {latest_version}", 30)
        download_and_install(latest_version)
    else:
        update_status("La aplicación ya está actualizada.", 100)
        launch_button.config(state="normal")

if __name__ == "__main__":
    update()
    root.mainloop()
