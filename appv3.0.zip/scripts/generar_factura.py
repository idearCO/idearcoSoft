import sys
import os
# Agregar el directorio raíz al PATH
script_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(script_dir, ".."))
sys.path.insert(0, root_dir)

from dependencies import *

# Configurar conexión con Google Sheets
SHEET_ID = "13nQ3OcOqOUoHoq6z-5OAGK7ptVQi6EOHLGM_0pmnCbQ"

scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]

#Obtener credenciales desde sqlite3
def obtener_credenciales_desde_db():
    try:
        # Conectar a la base de datos SQLite
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Obtener el token de Google desde la base de datos
        cursor.execute("SELECT value FROM config WHERE key = 'google_token'")
        resultado = cursor.fetchone()
        conn.close()

        if resultado:
            # Convertir el string del token en un diccionario JSON
            credenciales_json = json.loads(resultado[0])
            print("[INFO] Credenciales obtenidas desde SQLite.")
            return ServiceAccountCredentials.from_json_keyfile_dict(credenciales_json, [
                "https://spreadsheets.google.com/feeds",
                "https://www.googleapis.com/auth/drive"
            ])
        else:
            raise ValueError("Token de Google no encontrado en la base de datos.")

    except Exception as e:
        print(f"[ERROR] No se pudo cargar el token desde la base de datos: {e}")
        exit(1)

creds = obtener_credenciales_desde_db()  # La función ya retorna las credenciales correctas
client = gspread.authorize(creds)

# Cargar datos de clientes para obtener empresa que factura
def cargar_clientes():
    sheet = client.open_by_key(SHEET_ID).worksheet("db-Clientes")
    clientes_data = sheet.get_all_records()
    df_clientes = pd.DataFrame(clientes_data)
    df_clientes.columns = df_clientes.columns.str.strip().str.upper()
    
    # Construimos un dict: { cod_cliente: {"RAZON SOCIAL":..., "CUIT":...} }
    dict_clientes = {}
    for _, row in df_clientes.iterrows():
        codigo = row["CODIGO CLIENTE"]
        dict_clientes[codigo] = {
            "RAZON SOCIAL": row["RAZON SOCIAL"],
            "CUIT": row["CUIT"]
        }
    return dict_clientes


def actualizar_datos_pedido():
    pedido_numero = int(pedido_var.get().split(" - ")[0])
    pedido = next((p for p in PEDIDOS if p["NUMERO"] == pedido_numero), None)

    if not pedido:
        messagebox.showerror("Error", "No se encontró el pedido seleccionado.")
        return

    # 1) Mostrar CUIT
    codigo_cliente = pedido.get("CODIGO CLIENTE", None)

    # Verificar si existe en clientes_dict
    if codigo_cliente in clientes_dict:
     cuit = clientes_dict[codigo_cliente]["CUIT"]
     cuit_var.set(cuit)
    else:
     cuit_var.set("N/A")


    # 2) Revisar país (ya lo tienes)
    pais = pedido.get("EMPRESA", "")
    if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
        moneda_menu.config(state="disabled")
        entry_ratio_cambio.config(state="disabled")
    else:
        moneda_menu.config(state="readonly")
        on_moneda_changed()

    # 3) Monto total, facturado, etc. (igual a tu lógica actual)
    monto_total = float(pedido["SUBTOTAL [USD]"]) if pedido["SUBTOTAL [USD]"] else 0
    monto_facturado = obtener_monto_facturado(pedido_numero)
    resta_facturar = round(monto_total - monto_facturado, 2)

    label_monto_total.config(text=f"{monto_total:,.2f}")
    label_monto_facturado.config(text=f"{monto_facturado:,.2f}")
    label_resta_facturar.config(text=f"{resta_facturar:,.2f}")


# Cargar facturas
def cargar_facturas():
    sheet = client.open_by_key(SHEET_ID).worksheet("db-Facturas")
    facturas_data = sheet.get_all_records()
    return facturas_data

FACTURAS = cargar_facturas()

def obtener_monto_facturado(pedido_numero):
    monto_total = sum(float(f["Monto Facturado"]) for f in FACTURAS if str(f["Numero de Pedido"]) == str(pedido_numero))
    return monto_total

# Cargar datos de pedidos y cruzarlos con clientes para obtener la empresa que factura
def cargar_pedidos():
    sheet = client.open_by_key(SHEET_ID).worksheet("db-Pedidos")
    pedidos_data = sheet.get_all_records()
    df = pd.DataFrame(pedidos_data)
    df.columns = df.columns.str.strip().str.upper()

    df["SUBTOTAL [USD]"] = df["SUBTOTAL [USD]"].astype(str)
    df["SUBTOTAL [USD]"] = df["SUBTOTAL [USD]"].str.replace(r'(\d+)\.(\d{3}),(\d+)', r'\1\2.\3', regex=True)
    df["SUBTOTAL [USD]"] = pd.to_numeric(df["SUBTOTAL [USD]"], errors='coerce').fillna(0)

    # (cargar_clientes) ya hecho
    clientes_dict = cargar_clientes()
    df["RAZON SOCIAL"] = df["CODIGO CLIENTE"].map(
        lambda cod: clientes_dict[cod]["RAZON SOCIAL"] if cod in clientes_dict else ""
    )

    # REEMPLAZA ESTO:
    # df_pedidos = df.groupby(["NUMERO", "RAZON SOCIAL"], as_index=False)["SUBTOTAL [USD]"].sum()
    # AHORA INCLUYES CODIGO CLIENTE Y EMPRESA:
    df_pedidos = df.groupby(
        ["NUMERO", "EMPRESA", "RAZON SOCIAL", "CODIGO CLIENTE"],
        as_index=False
    )["SUBTOTAL [USD]"].sum()

    # Resto igual (facturado, filtrar, etc.)
    df_pedidos["FACTURADO"] = df_pedidos["NUMERO"].apply(lambda num: obtener_monto_facturado(num))
    df_pedidos = df_pedidos[df_pedidos["SUBTOTAL [USD]"] > df_pedidos["FACTURADO"]]

    return df, df_pedidos.to_dict(orient='records')

# Obtener el detalle de productos por pedido
def obtener_detalle_pedido(numero_pedido, df):
    df_detalle = df[df["NUMERO"] == numero_pedido].copy()

    df_detalle["FACTURADO_ITEM"] = df_detalle.apply(
        lambda row: obtener_monto_facturado_item(numero_pedido, row["CODIGO"]), 
        axis=1
    )

    df_detalle = df_detalle[
        df_detalle["SUBTOTAL [USD]"] > df_detalle["FACTURADO_ITEM"]
    ]

    # Incluir la columna "IVA [%]" para usarla después en la tabla
    return df_detalle[[
        "CODIGO",
        "DESCRIPCIÓN",
        "CANT",
        "PRECIO U [USD]",
        "SUBTOTAL [USD]",
        "IVA [%]"
    ]].to_dict(orient="records")

# Función para calcular facturas y generar cuotas
def calcular_factura():
    pedido_numero = int(pedido_var.get().split(" - ")[0])
    pedido = next(p for p in PEDIDOS if p["NUMERO"] == pedido_numero)
    monto_total = pedido["SUBTOTAL [USD]"]
    monto_facturado = obtener_monto_facturado(pedido_numero)
    monto_a_facturar = float(entry_monto_facturar.get() or 0)
    if monto_a_facturar <= 0:
        messagebox.showerror("Error", "El monto a facturar debe ser mayor a 0.")
        return

    resta_facturar = round(monto_total - monto_facturado, 2)
    if monto_a_facturar > resta_facturar:
        messagebox.showerror("Error", "El monto a facturar excede lo adeudado.")
        return
    cuotas_previas = 1 if monto_facturado > 0 else 0
    cuota_asignada = ""

    if monto_facturado == 0 and monto_a_facturar < resta_facturar:
        cuota_asignada = "CUOTA 1"
    elif monto_facturado > 0 and monto_a_facturar < resta_facturar:
        cuota_asignada = f"CUOTA {cuotas_previas + 1}"
    elif monto_facturado > 0 and monto_a_facturar >= resta_facturar:
        cuota_asignada = "CUOTA FINAL"

    label_resta_facturar.config(text=f"{resta_facturar:,.2f}")

    actualizar_tabla_productos(pedido_numero, monto_a_facturar, cuota_asignada)
    
    pedido_numero = int(pedido_var.get().split(" - ")[0])
    pedido_seleccionado = next(p for p in PEDIDOS if p["NUMERO"] == pedido_numero)
    pais = pedido_seleccionado.get("EMPRESA", "").upper()

    if pais in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
     # Toma la fecha que el usuario seleccionó en el calendar
     selected_date = calendar_fecha.get()      # Ejemplo: "2025-03-13"

     # Transforma a formato YYYYMMDD: "20250313"
     us_date_code = selected_date.replace("-", "")

     # Encuentra cuántas facturas hay en FACTURAS con esa misma fecha EXACTA.
     # Ojo: tu hoja de facturas debe guardar "Fecha" en "YYYY-MM-DD"
     facturas_misma_fecha = [f for f in FACTURAS if f["Fecha"] == selected_date]
     secuencia = len(facturas_misma_fecha) + 1

     numero_factura_auto = f"{us_date_code}/{secuencia:02d}"
    
     # Asigna el número al Entry
     entry_numero_factura.delete(0, tk.END)
     entry_numero_factura.insert(0, numero_factura_auto)
    else:
     # Si no es EEUU, limpiar para que el usuario pueda escribir manualmente
     entry_numero_factura.delete(0, tk.END)
     #guardar_factura(pedido_numero, monto_a_facturar, cuota_asignada)

# Guardar factura en db-Facturas
def on_guardar_factura():
    from datetime import datetime
    import json

    # 1) Obtener datos
    fecha = calendar_fecha.get()
    numero_factura = entry_numero_factura.get()

    # Verificar que haya un número de factura
    if not numero_factura.strip():
        messagebox.showerror("Error", "Debes ingresar el número de factura.")
        return  # Cancela el guardado

    pedido_numero = int(pedido_var.get().split(" - ")[0])
    pedido_seleccionado = next(p for p in PEDIDOS if p["NUMERO"] == pedido_numero)
    cliente = pedido_seleccionado.get("RAZON SOCIAL", "")  # O como definas esa columna

    monto_facturar = float(entry_monto_facturar.get() or 0)
    
    moneda_actual = moneda_var.get()  # "USD" o "ARS"
    try:
        ratio_cambio = float(entry_ratio_cambio.get()) if moneda_actual == "ARS" else 1.0
    except ValueError:
        ratio_cambio = 1.0

    # 2) Convertir la tabla de productos en JSON
    items = []
    for row_id in tree.get_children():
        row_values = tree.item(row_id, "values")
        items.append(row_values)
    detalle_items_json = json.dumps(items)

    # 3) Guardar datos en la hoja
    sheet = client.open_by_key(SHEET_ID).worksheet("db-Facturas")
    sheet.append_row([
        fecha,            # 1) Fecha
        numero_factura,   # 2) Número de Factura
        pedido_numero,    # 3) Número de Pedido
        cliente,          # 4) Cliente
        monto_facturar,   # 6) Monto Facturado
        moneda_actual,      # (8) Moneda
        ratio_cambio,       # (9) Ratio
        detalle_items_json # 7) Detalle Items
    ])

    # 4) Mensaje de éxito
    messagebox.showinfo("Éxito", "Factura guardada correctamente.")
    root.destroy()

def obtener_monto_facturado_item(num_pedido, cod_producto):
    # Recorres las facturas de 'FACTURAS'
    # y sumas lo que corresponde a este producto en cada factura
    # (dependerá de cómo almacenes el detalle de items facturados).
    # EJEMPLO genérico:
    total_pagado_item = 0.0
    for f in FACTURAS:
        if f["Numero de Pedido"] == num_pedido:
            # asumiendo que f["Detalle Items"] sea un JSON con filas [codigo, ...]
            # parsea y busca la línea con 'cod_producto'
            pass

    return total_pagado_item

# Actualizar tabla de productos en función del monto a facturar
def actualizar_tabla_productos(numero_pedido, monto_a_facturar, cuota_asignada):
    # 1) Obtener la EMPRESA (para saber si es ESTADOS UNIDOS)
    #    Asumiendo que en tu df_pedidos guardaste "EMPRESA" o similar
    tree.tag_configure("bold", font=("TkDefaultFont", 9, "bold"))  
    pedido = next(p for p in PEDIDOS if p["NUMERO"] == numero_pedido)
    pais = pedido["EMPRESA"].upper()
    # 2) Limpiar y redefinir columnas del Treeview
    for col in tree["columns"]:
        tree.heading(col, text="")  # limpias encabezados

    if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
    # Definir las 5 columnas
     tree["columns"] = ("Código", "Descripción", "Cantidad", "Precio U", "Subtotal")
     tree.heading("Código", text="Código")
     tree.heading("Descripción", text="Descripción")
     tree.heading("Cantidad", text="Cantidad")
     tree.heading("Precio U", text="Precio U")
     tree.heading("Subtotal", text="Subtotal")

     # Ajustar el ancho de cada columna (en píxeles) – ejemplo
     tree.column("Código", width=100, stretch=False)
     tree.column("Descripción", width=400, stretch=False)
     tree.column("Cantidad", width=80, stretch=False)
     tree.column("Precio U", width=80, stretch=False)
     tree.column("Subtotal", width=120, stretch=False)

    else:
     # Definir las 7 columnas
     tree["columns"] = ("Código", "Descripción", "Cantidad", "Precio U",
                       "Subtotal", "IVA", "Subtotal c/IVA")
     tree.heading("Código", text="Código")
     tree.heading("Descripción", text="Descripción")
     tree.heading("Cantidad", text="Cantidad")
     tree.heading("Precio U", text="Precio U")
     tree.heading("Subtotal", text="Subtotal")
     tree.heading("IVA", text="IVA")
     tree.heading("Subtotal c/IVA", text="Subtotal c/IVA")

     # Ajustar el ancho de cada una
     tree.column("Código", width=100, stretch=False)
     tree.column("Descripción", width=400, stretch=False)
     tree.column("Cantidad", width=80, stretch=False)
     tree.column("Precio U", width=80, stretch=False)
     tree.column("Subtotal", width=80, stretch=False)
     tree.column("IVA", width=50, stretch=False)
     tree.column("Subtotal c/IVA", width=120, stretch=False)


    # 3) Obtener los productos con "IVA [%]"
    productos = obtener_detalle_pedido(numero_pedido, DF_PEDIDOS)
    total_pedido = sum(p["SUBTOTAL [USD]"] for p in productos)
    # Borra filas antiguas
    for row in tree.get_children():
        tree.delete(row)

    # 4) Determinar si es ARS o USD
    moneda = moneda_var.get()  # "USD" / "ARS"
    ratio = 1.0
    if moneda == "ARS":
        try:
            ratio = float(entry_ratio_cambio.get())
        except ValueError:
            ratio = 0.0

    # 5) Recorrer productos y calcular
    total_factura = 0.0
    for prod in productos:
        factor = monto_a_facturar / total_pedido if total_pedido else 0
        cantidad = prod["CANT"]
        iva_porc = prod.get("IVA [%]", "0")  # str
        # Precio base (USD)
        precio_usd = prod["PRECIO U [USD]"]
        # Moneda
        if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
            # Price remains in USD, ignore ratio
            precio_unit = precio_usd
        else:
            # Si es Argentina, usar "USD" or "ARS" y ratio
            precio_unit = precio_usd * ratio if moneda == "ARS" else precio_usd
        
        # Aplica factor de facturación
        precio_facturado = precio_unit * factor
        precio_facturado = round(precio_facturado, 4)

        subtotal = precio_facturado * cantidad

        # Calcular IVA y subtotal c/IVA
        importe_iva = subtotal * (iva_porc / 100.0)
        subtotal_iva = subtotal + importe_iva
        
        if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
            total_factura += subtotal
        else:
            total_factura += subtotal_iva

        if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
            # Insertar SOLO 5 columnas
            tree.insert("", "end", values=(
                prod["CODIGO"],
                prod["DESCRIPCIÓN"],
                cantidad,
                f"{precio_facturado:,.2f}",
                f"{subtotal:,.2f}"
            ))
        else:
            # Insertar 7 columnas
            tree.insert("", "end", values=(
                prod["CODIGO"],
                prod["DESCRIPCIÓN"],
                cantidad,
                f"{precio_facturado:,.4f}",
                f"{subtotal:,.2f}",
                f"{iva_porc}%",
                f"{subtotal_iva:,.2f}"
            ))
          # 3) Agregar la fila final con la palabra "TOTAL"
    
    # Si hay cuota
    if cuota_asignada:
        if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
            tree.insert("", "end", values=("CUOT", cuota_asignada, "", "", ""))
        else:
            tree.insert("", "end", values=("CUOT", cuota_asignada, "1", "0", "", "", ""))
    
    if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
         tree.insert("", "end", values=("", "", "", "", ""), tags=())
    else:
         tree.insert("", "end", values=("", "", "", "", "", "", ""), tags=())  

    if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
         tree.insert("", "end", values=("", "", "", "", ""), tags=())
    else:
         tree.insert("", "end", values=("", "", "", "", "", "", ""), tags=()) 
    
    if pais.upper() in ["ESTADOS UNIDOS", "CHINA", "ARG"]:
     tree.insert("", "end", values=("TOTAL", "", "", "", f"{total_factura:,.2f}"), tags=("bold",))
    else:
     tree.insert("", "end", values=("TOTAL", "", "", "", "", "", f"{total_factura:,.2f}"), tags=("bold",))
    
def on_moneda_changed(*args):

    if moneda_var.get() == "ARS":
        entry_ratio_cambio.config(state="normal")
    else:
        entry_ratio_cambio.delete(0, tk.END)
        entry_ratio_cambio.config(state="disabled")

def on_double_click(event):
    # 1) Identificar la fila en la que ocurrió el doble clic
    row_id = tree.identify_row(event.y)
    if not row_id:
        return  # Clic fuera de filas

    # 2) Recuperar los valores de esa fila
    row_values = tree.item(row_id, "values")  # tupla con 5 o 7 columnas

    # 3) Crear ventana emergente
    popup = tk.Toplevel(root)
    popup.title("Detalles de la Fila Seleccionada")

    # 4) Crear un Text para mostrar info y permitir copia (sin edición)
    text = tk.Text(popup, width=60, height=10, wrap="none")
    text.pack(padx=10, pady=10)

    # 5) Determinar si son 5 o 7 columnas
    col_count = len(row_values)
    if col_count == 5:
        # Ejemplo: (CODIGO, DESCRIPCION, CANTIDAD, PRECIO U, SUBTOTAL)
        info_str = (
            f"CODIGO: {row_values[0]}\n"
            f"DESCRIPCION: {row_values[1]}\n"
            f"CANTIDAD: {row_values[2]}\n"
            f"PRECIO U: {row_values[3]}\n"
            f"SUBTOTAL: {row_values[4]}"
        )
    elif col_count == 7:
        # Ejemplo: (CODIGO, DESCRIPCION, CANTIDAD, PRECIO U, SUBTOTAL, IVA, SUBTOTAL c/IVA)
        info_str = (
            f"CODIGO: {row_values[0]}\n"
            f"DESCRIPCION: {row_values[1]}\n"
            f"CANTIDAD: {row_values[2]}\n"
            f"PRECIO U: {row_values[3]}\n"
            f"SUBTOTAL: {row_values[4]}\n"
            f"IVA: {row_values[5]}\n"
            f"SUBTOTAL c/IVA: {row_values[6]}"
        )
    else:
        # Caso que no encaje en 5 ni 7
        info_str = "No se puede presentar la información. (Cant. columnas desconocida)"

    # 6) Mostrar el texto
    text.insert("1.0", info_str)

    # Evitar edición pero permitir seleccionar y copiar
    text.config(state="disabled")

    # 7) Botón "Cerrar"
    btn_close = tk.Button(popup, text="Cerrar", command=popup.destroy)
    btn_close.pack(pady=5)



# Crear ventana
root = tk.Tk()
root.title("Generar Factura")
frame = tk.Frame(root, padx=10, pady=10)
frame.pack(pady=10)
default_font = ("Arial", 12)
root.option_add("*Font", default_font)


# Selección de pedido
clientes_dict = cargar_clientes()
DF_PEDIDOS, PEDIDOS = cargar_pedidos()
FACTURAS = cargar_facturas()

# Fecha
tk.Label(frame, text="Fecha:").grid(row=0, column=0, sticky="w")
calendar_fecha = DateEntry(frame, date_pattern='yyyy-mm-dd', width=30)  # Por ejemplo
calendar_fecha.grid(row=0, column=1)


# Selección de pedido
tk.Label(frame, text="Pedido:").grid(row=1, column=0, sticky="w")
pedido_var = tk.StringVar()
pedido_menu = ttk.Combobox(frame, width=30, textvariable=pedido_var, 
    values=[f"{p['NUMERO']} - {p['RAZON SOCIAL']}" for p in PEDIDOS], state="readonly")
pedido_menu.grid(row=1, column=1)
pedido_menu.bind("<<ComboboxSelected>>", lambda event: actualizar_datos_pedido())

pedido_menu.grid(row=1, column=1)

tk.Label(frame, text="CUIT:").grid(row=2, column=0, sticky="w")

cuit_var = tk.StringVar()
entry_cuit = tk.Entry(frame, textvariable=cuit_var, width=30, state="readonly")
entry_cuit.grid(row=2, column=1)


# Monto Total
tk.Label(frame, text="Monto Total:").grid(row=3, column=0, sticky="w")
label_monto_total = tk.Label(frame, text="0.00")
label_monto_total.grid(row=3, column=1)

# Monto Facturado
tk.Label(frame, text="Monto Facturado:").grid(row=4, column=0, sticky="w")
label_monto_facturado = tk.Label(frame, text="0.00")
label_monto_facturado.grid(row=4, column=1)

# Resta Facturar
tk.Label(frame, text="Resta Facturar:").grid(row=5, column=0, sticky="w")
label_resta_facturar = tk.Label(frame, text="0.00")
label_resta_facturar.grid(row=5, column=1)

# Monto a Facturar
tk.Label(frame, text="Monto a Facturar:").grid(row=6, column=0, sticky="w")
entry_monto_facturar = tk.Entry(frame, width=30)
entry_monto_facturar.grid(row=6, column=1)

# Moneda

tk.Label(frame, text="Moneda:").grid(row=7, column=0, sticky="w")
moneda_var = tk.StringVar(value="USD")  # Valor por defecto
moneda_menu = ttk.Combobox(
    frame, textvariable=moneda_var, values=["USD", "ARS"], state="readonly", width=27
)
moneda_menu.grid(row=7, column=1)
moneda_var.trace_add("write", on_moneda_changed)
# Ratio de Cambio (Entry), inicialmente deshabilitado
tk.Label(frame, text="Ratio de Cambio:").grid(row=8, column=0, sticky="w")
entry_ratio_cambio = tk.Entry(frame, width=30, state="disabled")
entry_ratio_cambio.grid(row=8, column=1)

# Botón Generar
btn_calcular = tk.Button(frame, text="Generar Detalle de Factura", command=calcular_factura)
btn_calcular.grid(row=9, column=0, columnspan=2, pady=5)

# Tabla de productos
tree = ttk.Treeview(frame, columns=("Código", "Descripción", "Cantidad", "Precio U"), show="headings")
tree.bind("<Double-1>", on_double_click)
tree.heading("Código", text="Código")
tree.heading("Descripción", text="Descripción")
tree.heading("Cantidad", text="Cantidad")
tree.heading("Precio U", text="Precio U")
# Crea un frame con tamaño fijo
tree.grid(row=10, column=0, columnspan=2, pady=5)

# Número de Factura
tk.Label(frame, text="Número de Factura:").grid(row=11, column=0, sticky="w")
entry_numero_factura = tk.Entry(frame, width=30)
entry_numero_factura.grid(row=11, column=1)

# Botón Guardar
btn_guardar = tk.Button(frame, text="Guardar Factura", command=on_guardar_factura)
btn_guardar.grid(row=12, column=0, columnspan=2, pady=10)



# Evitar que el usuario cambie el tamaño
#root.resizable(False, False)
#root.geometry("1000x600")  # Ejemplo
root.mainloop()




