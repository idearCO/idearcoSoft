# Librerías estándar de Python
import os
import sys
import zipfile
import subprocess
import sqlite3
import json
import threading
import time


# Librerías de terceros
import requests
from PIL import Image, ImageTk
import gspread
import pandas as pd
from oauth2client.service_account import ServiceAccountCredentials

# Librerías de GUI (Tkinter)
import tkinter as tk
from tkinter import ttk, Label, Button, messagebox
from tkcalendar import DateEntry
#PATCH Lanzado
#INSTALL_PATH = "C:\\idearcoSoft"

#PATCH Producción
INSTALL_PATH = "C:\\idearcoSoftInstaller\\Produccion"

#Patchs secundarios
DB_PATH = os.path.join(INSTALL_PATH, "config.db")
FAVICON_PATH = os.path.join(INSTALL_PATH, "favicon")
SCRIPTS_PATH = os.path.join(INSTALL_PATH, "scripts")
print("[INFO] Dependencias cargadas correctamente.")
