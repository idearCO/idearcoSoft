import tkinter as tk
from tkinter import messagebox

def login():
    username = entry_user.get()
    password = entry_pass.get()
    if username == "admin" and password == "1234":
        messagebox.showinfo("Login", "Inicio dpe sesión exitoso")
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrecta")

app = tk.Tk()
app.title("IdearcoSoft")
app.geometry("300x150")

label_user = tk.Label(app, text="Usuario:")
label_user.pack(pady=5)
entry_user = tk.Entry(app)
entry_user.pack(pady=5)

label_pass = tk.Label(app, text="Contraseña:")
label_pass.pack(pady=5)
entry_pass = tk.Entry(app, show="*")
entry_pass.pack(pady=5)

btn_login = tk.Button(app, text="Iniciar Sesión", command=login)
btn_login.pack(pady=10)

app.mainloop()
